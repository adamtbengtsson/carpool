def init():
    global listerino
    listerino = []