import os
from flaskblog import db, bcrypt
from flaskblog.models import User, CarManager, Car
from datetime import date
try:
    os.remove('flaskblog/site.db')
    print('previous DB file removed')
except:
    print('no previous file found')

db.create_all()

hashed_password = bcrypt.generate_password_hash('testing').decode('utf-8')
default_user1 = User(username='Default', email='default@test.com', password=hashed_password, std_destination='Malmo')
db.session.add(default_user1)

hashed_password = bcrypt.generate_password_hash('testing2').decode('utf-8')
default_user2 = User(username='Default Second', email='default2@test.com', password=hashed_password)
db.session.add(default_user2)


default_car = Car(car_name='VOLVO', model='720', license_plate='ABC123', fuel=75, seats=5, user=default_user1)

db.session.add(default_car)


booking1 = CarManager(user=default_user1, car=default_car, day=date.fromisoformat("2020-01-01"), destination=default_user1.std_destination, combination=f'{default_car.id}{date.fromisoformat("2020-01-01")}')

db.session.add(booking1)

db.session.commit()
print('finalized')